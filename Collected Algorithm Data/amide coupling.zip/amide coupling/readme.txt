This is the amide coupling dataset we collected. 

These are the full scope simulation results with HTE data, with activator and activator-base combinations as objectives.

